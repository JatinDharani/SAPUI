jQuery.sap.includeScript("/webapp/src/src/cordova.js");
sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("jatin.app.barcode.controller.Main", {
  onScan: function () {
	
cordova.plugins.barcodeScanner.scan(this.scanSuccessCallback,this.scanErrorCallback);

		},
		  scanSuccessCallback: function(result) {
                alert(result.text);
            },

            scanErrorCallback: function(error) {
                navigator.notification.alert("Scanning failed: " + JSON.stringify(error));
            }
	
	});
});